<?php $__env->startSection('title'); ?>
	<title>PT. Cahaya Panca Sukses Sentosa | Contact</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('amadeo/css/contact.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
	<div id="contacts" class="after-banner">
		<img id="top" src="<?php echo e(asset('amadeo/images-base/banner-b.png')); ?>">
		<div id="set-wrapper">
			<h1>Contact</h1>
			
			<div id="maps">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.9672184751503!2d106.82671841431291!3d-6.135106995557875!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6a1e02af564ea9%3A0xfdc3a529e38159eb!2sPrimalayan+Citra+Mandiri.+PT+(Datascrip+Service+Center)!5e0!3m2!1sid!2sid!4v1507604868031" frameborder="0" style="border:0" allowfullscreen></iframe>
			</div>

			<div id="contect-wrapper">
				<div id="descrip" class="bar">
					<h2>Address</h2>
					<div class="rows">
						<div class="cell">
							<img src="<?php echo e(asset('amadeo/images-base/icon-location.png')); ?>">
						</div>
						<div class="cell">
							<p>Jln. Kapuk Raya No 88, Samping Ruko Grisenda Jakarta Utara</p>
						</div>
					</div>
					<h2>Phones</h2>
					<div class="rows">
						<div class="cell">
							<img src="<?php echo e(asset('amadeo/images-base/icon-phone.png')); ?>">
						</div>
						<div class="cell">
							<p>021 6192424</p>
							<p>021 5417203</p>
						</div>
					</div>
					<h2>E-mail</h2>
					<div class="rows">
						<div class="cell">
							<img src="<?php echo e(asset('amadeo/images-base/icon-mail.png')); ?>">
						</div>
						<div class="cell">
							<p>pancalogam@ymail.com</p>
						</div>
					</div>
				</div>
				<div id="information" class="bar">
					<h2>Information</h2>
					<form class="form-style" method="post" action="<?php echo e(route('frontend.contact.store')); ?>">
						<?php if(Session::has('alert')): ?>
							<script>
							  window.setTimeout(function() {
							    $("#alret-form-kontak").fadeTo(700, 0).slideUp(700, function(){
							        $(this).remove();
							    });
							  }, 5000);
							</script>
					        <div id="alret-form-kontak" class="alert <?php echo e(Session::get('alert')); ?>">
					        	<strong><?php echo e(Session::get('info')); ?></strong>
					        </div>
						<?php endif; ?>
				        <?php echo e(csrf_field()); ?>

				        <div class="float margin">
					        <?php if($errors->has('name')): ?>
								<span><?php echo e($errors->first('name')); ?></span>
							<?php endif; ?>
							<input 
								type="text" 
								name="name"
								placeholder="Name"
								value="<?php echo e(old('name')); ?>"
								<?php echo e(Session::has('autofocus') ? 'autofocus' : ''); ?>

							>
				        	
				        	<?php if($errors->has('telpon')): ?>
								<span><?php echo e($errors->first('telpon')); ?></span>
							<?php endif; ?>
				        	<input 
								type="text" 
								name="telpon"
								placeholder="Telepon"
								onkeypress="return isNumber(event)"
								value="<?php echo e(old('telpon')); ?>"
							>
				        </div>
				        <div class="float">
							<?php if($errors->has('email')): ?>
								<span><?php echo e($errors->first('email')); ?></span>
							<?php endif; ?>
							<input 
								type="text" 
								name="email"
								placeholder="Email" 
								value="<?php echo e(old('email')); ?>"
							>
							
							<?php if($errors->has('subject')): ?>
								<span><?php echo e($errors->first('subject')); ?></span>
							<?php endif; ?>
							<input 
								type="text" 
								name="subject"
								placeholder="Subject" 
								value="<?php echo e(old('subject')); ?>"
							>
				        </div>
						<div class="clearfix"></div>
						<?php if($errors->has('pesan')): ?>
							<span><?php echo e($errors->first('pesan')); ?></span>
						<?php endif; ?>
						<textarea 
							name="pesan" 
							placeholder="Pesan"
							rows="2" 
						><?php echo e(old('pesan')); ?></textarea>
						<div class="submit-wrapper">
							<?php if($errors->has('g-recaptcha-response')): ?>
								<span><?php echo e($errors->first('g-recaptcha-response')); ?></span>
							<?php endif; ?>
							<div class="g-recaptcha" data-sitekey="6LfHAS4UAAAAAIR34oekoJOvk9WzQhc6utDRv9vK" data-callback="submitThisForm"></div>
							<button id="submit" class="btn-purple" type="submit">SUBMIT</button>
							<div class="clearfix"></div>
						</div>
					</form>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<img id="botom" src="<?php echo e(asset('amadeo/images-base/after-banner-b.png')); ?>">
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
	<script src='https://www.google.com/recaptcha/api.js'></script>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend._layouts.basic', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
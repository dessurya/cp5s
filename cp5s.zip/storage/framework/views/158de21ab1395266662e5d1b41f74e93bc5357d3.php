<div id="footer">
	<img id="top" src="<?php echo e(asset('amadeo/images-base/footer-a.png')); ?>">
	<div id="set-wrapper">
		<div id="content">
			<div id="logo" class="bar">
				<img src="<?php echo e(asset('amadeo/images-base/logo-cpss-putih.png')); ?>">
			</div>
			<div id="detail" class="bar">
				<div id="find-us">
					<h3>Find Us</h3>
					<a href="">
						<img src="<?php echo e(asset('amadeo/images-base/icon-fb-putih.png')); ?>">
					</a>
					<a href="">
						<img src="<?php echo e(asset('amadeo/images-base/icon-gplus-putih.png')); ?>">
					</a>
				</div>
				<div id="contact">
					<h3>Contact</h3>
					<p>
						JL. Mangga Dua Raya, Ruko Grand Boutique Centre Blok B no 59 Jakarta Utara 14430 cahayapancasukses@gmail.com
					</p>
					<p>021 34567877</p>
					<p>021 34568769</p>
				</div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div id="copyright">
			<label>© Copyright 2017 All Rights Reserved</label>
			<label>Development By <a href="http://amadeo.id/"><img src="<?php echo e(asset('amadeo/images-base/logo-amadeo.png')); ?>"></a></label>
		</div>
	</div>
</div>
<!DOCTYPE html>
<html>
<head>

<?php echo $__env->yieldContent('title'); ?>

	<meta charset="utf-8">
	<meta http-equiv="Content-Language" content="<?php echo e(App::getLocale()); ?>" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<?php echo $__env->yieldContent('meta'); ?>

	<link rel="icon" type="image/png" href="<?php echo e(asset('amadeo/images-base/logo-cpss-mini.png')); ?>" />
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('amadeo/font/font-family.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('amadeo/css/public.css')); ?>">
<?php echo $__env->yieldContent('style'); ?>

</head>
<body>

	<?php echo $__env->make('frontend._includes.navigasi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('body'); ?>
	<?php echo $__env->make('frontend._includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<script type="text/javascript" src="<?php echo e(asset('amadeo/plugin/jquery/jquery-3.2.0.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('amadeo/js/public.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>